chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (msg.action === "saveToken") {
    chrome.storage.local.set({
      sb_token: msg.token,
      sb_user:  msg.user,
    }, () => sendResponse({ ok: true }));
    return true;
  }
});