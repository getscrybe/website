// Guard against double-injection (manifest injects once, executeScript injects again)
if (typeof window.__scrybeLoaded === "undefined") {
window.__scrybeLoaded = true;

var stopTyping = false;
var typingSession = null; // { pause, resume, stop, isPaused } while a typing run is active

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "stop") {
    if (typingSession) typingSession.stop();
    else stopTyping = true;
    sendResponse({ stopped: true });
    return;
  }

  if (message.action === "pause") {
    if (typingSession) {
      typingSession.pause();
      sendResponse({ paused: typingSession.isPaused() });
    } else {
      sendResponse({ paused: false });
    }
    return;
  }

  if (message.action === "resume") {
    if (typingSession && typingSession.isPaused()) {
      typingSession.resume();
      sendResponse({ resumed: true });
    } else {
      sendResponse({ resumed: false });
    }
    return;
  }

  if (message.action !== "type") return;
  stopTyping = false;

  const { text, wpm } = message;
  const msPerChar = (60 / (wpm * 5)) * 1000;

  // ═══════════════════════════════════════════════════════════════════════════
  // KEYBOARD LAYOUT DATA
  // ═══════════════════════════════════════════════════════════════════════════

  const KEY_NEIGHBORS = {
    a: ["q","w","s","z"],          b: ["v","g","h","n"],
    c: ["x","d","f","v"],          d: ["s","e","r","f","c","x"],
    e: ["w","r","d","s"],          f: ["d","r","t","g","v","c"],
    g: ["f","t","y","h","b","v"],  h: ["g","y","u","j","n","b"],
    i: ["u","o","k","j"],          j: ["h","u","i","k","n","m"],
    k: ["j","i","o","l","m"],      l: ["k","o","p",";"],
    m: ["n","j","k",","],          n: ["b","h","j","m"],
    o: ["i","p","l","k"],          p: ["o","l",";"],
    q: ["w","a"],                  r: ["e","t","f","d"],
    s: ["a","w","e","d","x","z"],  t: ["r","y","g","f"],
    u: ["y","i","j","h"],          v: ["c","f","g","b"],
    w: ["q","e","a","s"],          x: ["z","s","d","c"],
    y: ["t","u","h","g"],          z: ["a","s","x"],
    " ": ["v","b","n","c","m"],
    ",": ["m","l","."],            ".": [",","/","l"],
    ";": ["l","p","/"],            "'": [";","p"],
  };

  const KEY_FINGER = {
    q:0,a:0,z:0, w:1,s:1,x:1, e:2,d:2,c:2,
    r:3,f:3,v:3,t:3,g:3,b:3,
    y:4,h:4,n:4,u:4,j:4,m:4,
    i:5,k:5,",":5, o:6,l:6,".":6, p:7,";":7,"'":7,
    " ":4,
  };

  const FAR_KEYS = new Set(["q","p","z","1","2","9","0"]);
  const MID_KEYS = new Set(["t","g","r","u","h","n","b","y"]);

  const FAST_BIGRAMS = new Set([
    "th","he","in","er","an","re","on","en","at","es",
    "ed","nd","to","or","ea","ti","ar","te","ng","al",
    "it","as","is","ha","se","ou","of","le","ve","de","co",
  ]);
  const SLOW_BIGRAMS = new Set([
    "un","lo","ol","ki","ce","ec","fr","rf","gr","mu","ju","hy",
  ]);
  const COMMON_WORDS = new Set([
    "the","and","that","have","for","not","with","you","this","but",
    "his","from","they","say","her","she","will","one","all","would",
    "there","their","what","out","about","who","get","which","when",
    "make","can","like","time","just","him","know","take","into",
    "your","good","some","could","them","see","other","than","then",
    "now","look","only","come","its","over","also","back","after",
  ]);

  // ═══════════════════════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════════════════════

  function randNormal() {
    return (
      Math.sqrt(-2 * Math.log(Math.random())) *
      Math.cos(2 * Math.PI * Math.random())
    );
  }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function rand(lo, hi)     { return lo + Math.random() * (hi - lo); }

  // Log-normal IKI — matches real keystroke dynamics research
  function iki(mult = 1) {
    const base  = msPerChar * mult;
    const sigma = 0.32;
    const lm    = Math.log(base) - (sigma * sigma) / 2;
    return clamp(Math.exp(lm + sigma * randNormal()), 28, base * 4);
  }

  function wordDifficulty(word) {
    const w = word.toLowerCase().replace(/[^a-z]/g, "");
    if (w.length <= 3) return 0;
    if (w.length <= 5) return 0.25;
    if (w.length <= 8) return 0.55;
    return 0.9;
  }

  function holdDuration(char) {
    if (char === "Backspace") return Math.round(rand(50, 95));
    if (char === " ")         return Math.round(rand(55, 130));
    if (char === "\n")        return Math.round(rand(55, 115));
    const lower    = char.toLowerCase();
    const isUpper  = char !== lower;
    const base     = isUpper ? rand(75, 150) : rand(45, 120);
    const farBonus = FAR_KEYS.has(lower) ? rand(8, 25) : 0;
    return Math.round(base + farBonus);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // WORD META
  // ═══════════════════════════════════════════════════════════════════════════

  function buildWordMeta(text) {
    const meta = Array.from({ length: text.length }, () => ({
      posInWord: 0, wordLen: 0, word: "", isCommon: false,
    }));
    let i = 0;
    while (i < text.length) {
      if (/[a-zA-Z']/.test(text[i])) {
        let j = i;
        while (j < text.length && /[a-zA-Z']/.test(text[j])) j++;
        const word     = text.slice(i, j);
        const isCommon = COMMON_WORDS.has(word.toLowerCase());
        for (let k = i; k < j; k++) {
          meta[k] = { posInWord: k - i, wordLen: word.length, word, isCommon };
        }
        i = j;
      } else {
        i++;
      }
    }
    return meta;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SEQUENCE BUILDER
  // ═══════════════════════════════════════════════════════════════════════════

  function buildSequence(text) {
    const seq = [];
    const wordMeta = buildWordMeta(text);

    let warmup    = Math.floor(rand(5, 14));
    let burst     = 0;
    let fatigue   = 0;
    let hesitant  = 0;       // chars right after a thinking pause — typed slower
    let charsTyped = 0;
    let prevChar   = "";
    let prevFinger = -1;

    // Typo budget: roughly 1 typo per ~120 chars (always corrected immediately)
    // Real essay writers make ~0.5–1.5% error rate, nearly all self-corrected
    const BASE_TYPO_RATE = 0.015; // ~1.1–1.3% per character — normal human typists

    // Characters until the current sentence ends — used to scale how long a
    // writer "thinks" before starting the next sentence.
    function countToSentenceEnd(from) {
      for (let j = from; j < text.length; j++) {
        if ("?!.".includes(text[j]) || text[j] === "\n") return j - from;
      }
      return text.length - from;
    }

    let i = 0;
    while (i < text.length) {
      const char   = text[i];
      const lower  = char.toLowerCase();
      const meta   = wordMeta[i];
      const finger = KEY_FINGER[lower] ?? -1;
      const isUpper = char !== lower && char === char.toUpperCase();

      // ── Base delay ───────────────────────────────────────────────────────
      let delay;
      if (warmup > 0) {
        delay = iki(rand(1.5, 2.2)); warmup--;
      } else if (burst > 0) {
        delay = iki(rand(0.30, 0.45)); burst--;
      } else {
        delay = iki(1);
      }

      // ── Fatigue (very mild — essay writing, not a marathon) ──────────────
      fatigue = Math.min(1, charsTyped / 2500);
      delay  *= (1 + fatigue * 0.15);

      // ── Bigram timing ────────────────────────────────────────────────────
      const bigram = prevChar + lower;
      if (FAST_BIGRAMS.has(bigram))      delay *= rand(0.58, 0.80);
      else if (SLOW_BIGRAMS.has(bigram)) delay *= rand(1.18, 1.50);

      // Same-finger penalty
      if (finger !== -1 && finger === prevFinger) delay *= rand(1.2, 1.55);

      // Hand-alternation bonus
      if (finger !== -1 && prevFinger !== -1) {
        const ph = prevFinger <= 3 ? 0 : 1;
        const ch = finger      <= 3 ? 0 : 1;
        if (ph !== ch) delay *= rand(0.84, 0.96);
      }

      // ── Key distance ─────────────────────────────────────────────────────
      if (FAR_KEYS.has(lower))      delay *= rand(1.08, 1.30);
      else if (MID_KEYS.has(lower)) delay *= rand(1.02, 1.12);

      // Double-letter slowdown
      if (lower === prevChar && lower !== " ") delay *= rand(1.12, 1.40);

      // Shift overhead
      if (isUpper) delay += rand(35, 100);

      // ── Thinking pauses ──────────────────────────────────────────────────
      // These are the "what do I write next?" moments. Real writers pause,
      // re-read their prompt, and stew on the next sentence or paragraph.
      if (prevChar === "\n") {
        // Starting a new paragraph: map out the next block before writing it.
        delay += rand(700, 2600);
        if (Math.random() < 0.30) delay += rand(1500, 4500);
      } else if (".!?".includes(prevChar)) {
        // New sentence: the pause scales with how long/elaborate it is.
        const ahead = countToSentenceEnd(i);
        delay += rand(350, 850) + ahead * rand(2, 6);
        if (Math.random() < 0.18) delay += rand(1200, 4200); // stalling, thinking
        if (Math.random() < 0.12) delay += rand(500, 1600);  // glancing back at the prompt
        hesitant = 2;                                        // first letters come out carefully
      } else if (",;".includes(prevChar)) {
        delay += rand(90, 300);
      } else if (prevChar === ":") {
        delay += rand(150, 420);
      }
      if (char === "\n") delay += rand(120, 380);          // newline keypress itself

      // Slow, deliberate first strokes right after a long think
      if (hesitant > 0) { delay *= rand(1.15, 1.45); hesitant--; }

      // ── Word-boundary hesitation ─────────────────────────────────────────
      if (meta.posInWord === 0 && meta.wordLen > 0) {
        const diff = meta.isCommon ? 0 : wordDifficulty(meta.word);
        delay += diff * rand(60, 200);

        // False start: occasionally begin the wrong word, catch it, and erase
        // it — a classic "thinking while typing" tell.
        const atSentenceStart = i === 0 || "?!.".includes(prevChar) || prevChar === "\n";
        const falseStartChance = atSentenceStart ? 0.05 : 0.02;
        if (meta.wordLen >= 3 && Math.random() < falseStartChance) {
          const k = meta.wordLen >= 5
            ? Math.floor(rand(2, Math.min(6, meta.wordLen) + 1))
            : 2;
          for (let j = 0; j < k; j++) {
            const c = text[i + j];
            seq.push({ char: c, delay: iki(rand(0.3, 0.5)), holdMs: holdDuration(c), progress: 0 });
          }
          for (let j = 0; j < k; j++) {
            seq.push({ char: "Backspace", delay: rand(40, 110), holdMs: 70 });
          }
          delay += rand(350, 1000); // staring at the erased half-word
        }

        // Common words often get typed in one quick, automatic burst.
        if (meta.isCommon && Math.random() < 0.50) burst = meta.wordLen - 1;
      }

      // Mid-word stumble on longer, less familiar words.
      if (burst === 0 && meta.wordLen > 4 && !meta.isCommon && meta.posInWord > 0 && Math.random() < 0.05) {
        delay += rand(120, 520);
      }
      // Second letter of any word ≥ 6 chars engages a touch slower.
      if (burst === 0 && meta.posInWord === 1 && meta.wordLen >= 6) delay += rand(70, 240);

      // ── Random micro/macro pauses ────────────────────────────────────────
      // Never interrupt a burst — fast stretches flow until a word boundary.
      if (burst === 0) {
        if (Math.random() < 0.010) delay += rand(400, 2000);     // brief distraction
        if (Math.random() < 0.006) delay += rand(1200, 4200);    // reconsidering a word choice
        if (Math.random() < 0.0035) delay += rand(2500, 6500);   // spacing out entirely
      }

      // Tiring near the end of a long essay — wraps up a little slower.
      if (burst === 0 && text.length > 500 && charsTyped > text.length * 0.85) {
        delay *= rand(1.05, 1.25);
      }

      // ── Burst trigger ────────────────────────────────────────────────────
      // More frequent now, and a burst always runs through the end of the
      // current word — fast stretches never cut off mid-word.
      if (burst === 0 && Math.random() < 0.09) {
        burst = Math.max(meta.wordLen - meta.posInWord, Math.floor(rand(6, 14)));
      }

      delay = Math.max(25, delay);

      // ── Typo logic ───────────────────────────────────────────────────────
      // Only on real typeable letters, not spaces/newlines/punctuation.
      const neighbors = KEY_NEIGHBORS[lower];
      const isLetter  = /[a-z]/.test(lower);
      const atSentenceStart = i === 0 || "?!.".includes(prevChar) || prevChar === "\n";

      // Error rate is not uniform: hard/rare words attract more mistakes,
      // common words fewer, and fast burst stretches are sloppier.
      let typoRate = BASE_TYPO_RATE * (1 + fatigue * 0.5);
      if (meta.isCommon)          typoRate *= 0.45;
      else if (meta.wordLen >= 8) typoRate *= 1.9;
      else if (meta.wordLen >= 5) typoRate *= 1.2;
      if (meta.posInWord === 0)   typoRate *= 1.35;
      if (burst > 0)              typoRate *= 1.8;

      const canTranspose = isLetter && i + 1 < text.length && /[a-z]/.test(text[i+1]);
      const doTranspose  = canTranspose && Math.random() < typoRate * 0.30;
      const doSubstitute = !doTranspose && isLetter && neighbors && Math.random() < typoRate * 0.45;
      const doDouble     = !doTranspose && !doSubstitute && isLetter && Math.random() < typoRate * 0.20;
      const doCapSlip    = !doTranspose && !doSubstitute && !doDouble && atSentenceStart && isUpper && Math.random() < 0.05;
      const doDblSpace   = !doTranspose && !doSubstitute && !doDouble && !doCapSlip && char === " " && text[i+1] && /[a-zA-Z]/.test(text[i+1]) && Math.random() < 0.05;

      if (doTranspose) {
        // Type next char first, then current, then immediately fix both
        const next = text[i + 1];
        seq.push({ char: next, delay,       holdMs: holdDuration(next), progress: 0 });
        seq.push({ char,       delay: iki(0.65), holdMs: holdDuration(char), progress: 0 });
        // Pause as person notices the swap, then backspace twice and retype
        seq.push({ char: "Backspace", delay: rand(150, 420), holdMs: 65 });
        seq.push({ char: "Backspace", delay: rand(40,  90),  holdMs: 65 });
        seq.push({ char,       delay: iki(0.9),  holdMs: holdDuration(char),  progress: 1 });
        seq.push({ char: next, delay: iki(0.75), holdMs: holdDuration(next), progress: 1 });
        i += 2;

      } else if (doSubstitute) {
        // Type wrong nearby key, notice it, backspace, retype correctly
        const wrongLower = neighbors[Math.floor(Math.random() * neighbors.length)];
        const wrongChar  = isUpper ? wrongLower.toUpperCase() : wrongLower;
        seq.push({ char: wrongChar,   delay,           holdMs: holdDuration(wrongChar), progress: 0 });
        seq.push({ char: "Backspace", delay: rand(90, 340), holdMs: 65 });
        seq.push({ char,              delay: iki(0.88),   holdMs: holdDuration(char), progress: 1 });
        i++;

      } else if (doDouble) {
        // Doubled key (sticky finger): the extra press is noticed and deleted
        seq.push({ char,            delay: iki(0.5),     holdMs: holdDuration(char), progress: 1 });
        seq.push({ char,            delay: iki(0.32),    holdMs: holdDuration(char), progress: 0 });
        seq.push({ char: "Backspace", delay: rand(140, 700), holdMs: 65 });
        i++;

      } else if (doCapSlip) {
        // Lowercase slip opening a sentence, caught and fixed quickly
        seq.push({ char: lower,        delay: iki(0.8),  holdMs: holdDuration(lower), progress: 0 });
        seq.push({ char: "Backspace",  delay: rand(120, 460), holdMs: 65 });
        seq.push({ char,               delay: iki(0.9),  holdMs: holdDuration(char),  progress: 1 });
        i++;

      } else if (doDblSpace) {
        // Double-tapped spacebar — the extra space is deleted a beat later
        seq.push({ char: " ",          delay: iki(1),      holdMs: holdDuration(" "), progress: 1 });
        seq.push({ char: " ",          delay: iki(0.30),   holdMs: holdDuration(" "), progress: 0 });
        seq.push({ char: "Backspace",  delay: rand(300, 900), holdMs: 65 });
        i++;

      } else {
        seq.push({ char, delay, holdMs: holdDuration(char), progress: 1 });
        i++;
      }

      prevChar   = lower;
      prevFinger = finger;
      charsTyped++;
    }

    return seq;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // EVENT DISPATCH
  // ═══════════════════════════════════════════════════════════════════════════

  function dispatchKey(doc, char, holdMs) {
    const isBackspace = char === "Backspace";
    const isNewline   = char === "\n";
    const isUpper     = !isBackspace && !isNewline && char >= "A" && char <= "Z";

    let key, keyCode, charCode;
    if (isBackspace) { key = "Backspace"; keyCode = 8;  charCode = 0;  }
    else if (isNewline) { key = "Enter";  keyCode = 13; charCode = 13; }
    else { key = char; keyCode = char.charCodeAt(0); charCode = keyCode; }

    const down = { key, keyCode, which: keyCode, charCode, shiftKey: isUpper, bubbles: true, cancelable: true };

    doc.body.dispatchEvent(new KeyboardEvent("keydown", down));
    if (!isBackspace) doc.body.dispatchEvent(new KeyboardEvent("keypress", { ...down, charCode }));

    if (isBackspace) {
      doc.body.dispatchEvent(new InputEvent("input", { inputType: "deleteContentBackward", bubbles: true }));
    } else if (isNewline) {
      doc.body.dispatchEvent(new InputEvent("input", { inputType: "insertParagraph", bubbles: true }));
    } else {
      doc.body.dispatchEvent(new InputEvent("input", { data: char, inputType: "insertText", bubbles: true }));
    }

    setTimeout(() => {
      doc.body.dispatchEvent(new KeyboardEvent("keyup", { key, keyCode, which: keyCode, shiftKey: isUpper, bubbles: true }));
    }, holdMs);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // MAIN
  // ═══════════════════════════════════════════════════════════════════════════

  const editor = document.querySelector(".docs-texteventtarget-iframe");
  if (!editor) { sendResponse({ error: "Could not find doc editor" }); return; }

  const editorDoc = editor.contentDocument;
  editorDoc.body.focus();

  setTimeout(() => {
    const sequence = buildSequence(text);
    const total    = text.length;          // progress is measured against the real string
    let idx = 0;
    let completeChars = 0;                 // chars of the string actually landed
    let lastPct = -1;
    let paused = false;
    let timer = null;
    let pending = null;   // step waiting to be dispatched while paused
    let done = false;

    function reportProgress() {
      try {
        const pct = Math.min(100, Math.round(completeChars / total * 100));
        if (pct === lastPct) return;
        lastPct = pct;
        chrome.runtime.sendMessage({ type: "scrybe-progress", pct }, () => {});
      } catch (e) { /* messaging not required */ }
    }

    function finishStopped() {
      if (done) return;
      done = true;
      typingSession = null;
      sendResponse({ stopped: true });
    }

    function finishDone() {
      if (done) return;
      done = true;
      typingSession = null;
      completeChars = total;
      reportProgress();
      sendResponse({ done: true });
    }

    function scheduleStep() {
      if (stopTyping) { finishStopped(); return; }
      if (idx >= sequence.length) { finishDone(); return; }

      const item = pending || sequence[idx++];
      pending = item;

      timer = setTimeout(() => {
        timer = null;
        pending = null;
        if (paused) return;
        if (stopTyping) { finishStopped(); return; }
        dispatchKey(editorDoc, item.char, item.holdMs);
        if (item.progress) completeChars += item.progress;
        reportProgress();
        scheduleStep();
      }, item.delay);
    }

    typingSession = {
      isPaused: () => paused,
      pause() {
        if (paused || done || stopTyping) return paused;
        paused = true;
        if (timer) { clearTimeout(timer); timer = null; }
        return paused;
      },
      resume() {
        if (!paused || done || stopTyping) return false;
        paused = false;
        scheduleStep();
        return true;
      },
      stop() {
        stopTyping = true;
        if (paused) { paused = false; scheduleStep(); }
      }
    };

    reportProgress();
    scheduleStep();
  }, rand(250, 750));

  return true;
});

} // end __scrybeLoaded guard