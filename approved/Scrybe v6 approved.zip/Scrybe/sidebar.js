// ─────────────────────────────────────────────
//  SUPABASE CONFIG
// ─────────────────────────────────────────────
const SUPABASE_URL  = "https://ajswovsdbdeohuyyucyo.supabase.co";
const SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFqc3dvdnNkYmRlb2h1eXl1Y3lvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzMTEwNDYsImV4cCI6MjA4OTg4NzA0Nn0.N5NyNjP1fc7fxZm08DbNAlx-hGOlfCYXrlpezt_EG9c";

const TIER_LIMITS = {
  free:      { essays: 2,        maxWords: 500,      maxWpm: 60  },
  pro:       { essays: 20,       maxWords: 5000,     maxWpm: Infinity },
  unlimited: { essays: 200, maxWords: Infinity, maxWpm: Infinity },
};

// ─────────────────────────────────────────────
//  SESSION STATE
// ─────────────────────────────────────────────
let currentUser   = null;  // { id, email, name }
let currentToken  = null;  // Supabase JWT
let currentRefresh = null; // Supabase refresh token (for silent renewal)
let currentTier  = "free";
let essayCount   = 0;

// ─────────────────────────────────────────────
//  REFS
// ─────────────────────────────────────────────
const pageLogin         = document.getElementById("pageLogin");
const pageForm          = document.getElementById("pageForm");
const pageOutline       = document.getElementById("pageOutline");
const pageDraft         = document.getElementById("pageDraft");
const pagePreview       = document.getElementById("pagePreview");

const loginBtn          = document.getElementById("loginBtn");
const userBar           = document.getElementById("userBar");
const userAvatar        = document.getElementById("userAvatar");
const userEmailEl       = document.getElementById("userEmail");
const essayUsageEl      = document.getElementById("essayUsage");
const tierBadgeEl       = document.getElementById("tierBadge");
const upgradeBtnEl      = document.getElementById("upgradeBtn");

const subjectEl         = document.getElementById("subject");
const otherWrap         = document.getElementById("otherSubjectWrap");
const otherSubjectEl    = document.getElementById("otherSubject");
const wordCountEl       = document.getElementById("wordCount");
const wordCountCrown    = document.getElementById("wordCountCrown");
const gradeLevelEl      = document.getElementById("gradeLevel");
const rubricEl          = document.getElementById("rubric");
const instructionsEl    = document.getElementById("instructions");
const outlineToggle     = document.getElementById("outlineToggle");
const outlineSw         = document.getElementById("outlineSw");
const outlineCrown      = document.getElementById("outlineCrown");
const genBtn            = document.getElementById("genBtn");
const outlineNextBtn    = document.getElementById("outlineNextBtn");
const draftBackBtn      = document.getElementById("draftBackBtn");
const outlineBackBtn    = document.getElementById("outlineBackBtn");
const applyBtn          = document.getElementById("applyBtn");
const approveBtn        = document.getElementById("approveBtn");
const backBtn           = document.getElementById("backBtn");
const typeBtn           = document.getElementById("typeBtn");
const pauseBtn          = document.getElementById("pauseBtn");
const stopBtn           = document.getElementById("stopBtn");
const typeControlsEl    = document.querySelector(".type-controls");
const statusEl          = document.getElementById("status");
const draftTextEl       = document.getElementById("draftText");
const changesNoteEl     = document.getElementById("changesNote");
const essayEl           = document.getElementById("essayText");
const wordCountBadge    = document.getElementById("wordCountBadge");
const typingAnim        = document.getElementById("typingAnim");
const typingAnimLabel   = document.getElementById("typingAnimLabel");
const outlineBox        = document.getElementById("outlineBox");
const genOverlay        = document.getElementById("genOverlay");
const draftOverlay      = document.getElementById("draftOverlay");
const wpmEl             = document.getElementById("wpm");
const wpmCrown          = document.getElementById("wpmCrown");
const typingProgress    = document.getElementById("typingProgress");
const typingProgressFill  = document.getElementById("typingProgressFill");
const typingProgressLabel = document.getElementById("typingProgressLabel");
const skeletonOverlay     = document.getElementById("skeletonOverlay");
const skeletonOverlayLabel = document.getElementById("skeletonOverlayLabel");
const confettiEl            = document.getElementById("confetti");

// ─────────────────────────────────────────────
//  COSMETIC HELPERS — toasts, skeletons, progress, confetti
// ─────────────────────────────────────────────
const TOAST_ICONS = {
  ok:   '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8.5l3.5 3.5L13 5"/></svg>',
  err:  '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
  warn: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3L14 13H2z"/><path d="M8 7v3M8 12v.01"/></svg>'
};

function showToast(message, type = "ok") {
  const stack = document.getElementById("toastStack");
  if (!stack) return;
  if (scrollHintEl) {
    scrollHintEl.classList.add("dismissed");
    scrollHintEl.classList.remove("visible");
  }
  const toast = document.createElement("div");
  toast.className = "toast " + type;
  const icon = document.createElement("span");
  icon.className = "toast-icon";
  icon.innerHTML = TOAST_ICONS[type] || TOAST_ICONS.ok;
  const msg = document.createElement("span");
  msg.textContent = message;
  toast.appendChild(icon);
  toast.appendChild(msg);
  stack.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("leaving");
    setTimeout(() => toast.remove(), 260);
  }, 3200);
}

// Shimmer placeholder lines inside the outline box
function renderSkeletonLines(container, count) {
  container.innerHTML = "";
  const label = document.createElement("div");
  label.className = "outline-status";
  label.textContent = "Writing draft…";
  container.appendChild(label);
  for (let i = 0; i < count; i++) {
    const line = document.createElement("div");
    line.className = "skeleton";
    line.style.width = (55 + Math.random() * 40) + "%";
    container.appendChild(line);
  }
}

function showSkeletonOverlay(label) {
  if (skeletonOverlayLabel) skeletonOverlayLabel.textContent = label || "Writing draft…";
  skeletonOverlay.classList.add("active");
}

function hideSkeletonOverlay() {
  skeletonOverlay.classList.remove("active");
}

// Live typing progress (driven by content.js messages)
function updateTypingProgress(pct) {
  typingProgress.classList.add("active");
  typingProgressFill.style.width = Math.max(0, Math.min(100, pct)) + "%";
  typingProgressLabel.textContent = Math.round(pct) + "%";
}

function resetTypingProgress() {
  typingProgress.classList.remove("active");
  typingProgressFill.style.width = "0%";
  typingProgressLabel.textContent = "0%";
}

// Lightweight confetti burst (no libraries, CSS-driven)
function fireConfetti() {
  if (!confettiEl || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const colors = ["#0066cc", "#0077ed", "#34c759", "#ff9500", "#a259ff", "#ff3b30"];
  confettiEl.innerHTML = "";
  for (let i = 0; i < 40; i++) {
    const piece = document.createElement("div");
    piece.className = "confetti-piece";
    piece.style.left = Math.random() * 100 + "%";
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDelay = (Math.random() * 0.4).toFixed(2) + "s";
    piece.style.animationDuration = (0.9 + Math.random() * 0.8).toFixed(2) + "s";
    piece.style.setProperty("--drift", (Math.random() * 80 - 40).toFixed(1) + "px");
    confettiEl.appendChild(piece);
  }
  setTimeout(() => { confettiEl.innerHTML = ""; }, 2400);
}

// Progress messages streamed from content.js while it types into the doc
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "scrybe-progress" && typeof msg.pct === "number") {
    updateTypingProgress(msg.pct);
  }
  sendResponse({ ok: true });
});

// ─────────────────────────────────────────────
//  PAGE TRANSITIONS
// ─────────────────────────────────────────────
const pages = [pageLogin, pageForm, pageOutline, pageDraft, pagePreview];

function goTo(page) {
  pages.forEach(p => {
    p.classList.remove("page-enter", "page-exit");
    if (p !== page) p.classList.add("page-hidden");
  });
  page.classList.remove("page-hidden");
  page.classList.add("page-enter");
  setTimeout(() => page.classList.remove("page-enter"), 300);
  refreshScrollHint();
}

// ─────────────────────────────────────────────
//  SCROLL HINT — tells users a page can scroll
// ─────────────────────────────────────────────
const scrollHintEl = document.getElementById("scrollHint");

function refreshScrollHint() {
  if (!scrollHintEl) return;
  const page = pages.find(p => !p.classList.contains("page-hidden"));
  if (!page) return;
  const overflows = page.scrollHeight > page.clientHeight + 4;
  const dismissed = scrollHintEl.classList.contains("dismissed");
  scrollHintEl.classList.toggle("visible", overflows && !dismissed);
}

pages.forEach(page => {
  page.addEventListener("scroll", () => {
    scrollHintEl.classList.add("dismissed");
    scrollHintEl.classList.remove("visible");
  });
});

window.addEventListener("resize", refreshScrollHint);
window.addEventListener("load", refreshScrollHint);
setTimeout(refreshScrollHint, 400);

outlineBackBtn.addEventListener("click", () => goTo(pageForm));
draftBackBtn.addEventListener("click",   () => goTo(outlineOn ? pageOutline : pageForm));

// Track what page preview was reached from so back goes to the right place
let previewOrigin = pageDraft; // default

function goToPreview(from) {
  previewOrigin = from;
  goTo(pagePreview);
}

backBtn.addEventListener("click", () => goTo(previewOrigin));

// ─────────────────────────────────────────────
//  AUTH — LOAD SESSION + TOKEN REFRESH
// ─────────────────────────────────────────────

// Decode JWT payload without a library
function parseJwt(token) {
  try {
    return JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
  } catch { return null; }
}

// Returns true if token expires within the next 5 minutes
function tokenExpiresSoon(token) {
  const payload = parseJwt(token);
  if (!payload || !payload.exp) return true;
  return (payload.exp * 1000) - Date.now() < 5 * 60 * 1000;
}

// Real Supabase token refresh. Supabase returns a new access token AND a
// rotated refresh token, so both are stored. Returns false when no refresh
// token is available or the refresh is rejected.
async function refreshToken() {
  if (!currentRefresh) return false;
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
      method: "POST",
      headers: {
        "apikey":       SUPABASE_ANON,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ refresh_token: currentRefresh }),
    });
    if (!res.ok) return false;
    const json = await res.json();
    if (!json.access_token) return false;
    currentToken   = json.access_token;
    currentRefresh = json.refresh_token || currentRefresh;
    if (json.user) {
      currentUser = {
        id:    json.user.id,
        email: json.user.email,
        name:  (json.user.user_metadata && json.user.user_metadata.name) || json.user.email,
      };
    }
    chrome.storage.local.set({ sb_token: currentToken, sb_refresh: currentRefresh, sb_user: currentUser });
    return true;
  } catch { return false; }
}

async function silentRefresh() {
  if (!currentToken) return false;
  // Try a real refresh first — the access token is renewed for another hour.
  if (await refreshToken()) return true;
  try {
    // No refresh token available — check whether the access token is still valid.
    const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: {
        "apikey":        SUPABASE_ANON,
        "Authorization": `Bearer ${currentToken}`,
      }
    });
    if (res.ok) return true;
    // 401 means the token is dead — try the dev auto-login before giving up
    if (res.status === 401) {
      if (await devAutoLogin()) return true;
    } else {
      return false; // server hiccup — keep the session, retry later
    }
  } catch { return false; } // network hiccup — keep the session, retry later
  chrome.storage.local.remove(["sb_token", "sb_user", "sb_refresh"]);
  currentToken   = null;
  currentUser    = null;
  currentRefresh = null;
  goTo(pageLogin);
  return false;
}

// ─────────────────────────────────────────────
//  DEV AUTO-LOGIN (local testing only)
//  Only activates if storage contains `dev_creds`
//  = { email, password } for a real Supabase user.
//  Never set in production, so this is a no-op there.
// ─────────────────────────────────────────────
async function devAutoLogin() {
  return new Promise(resolve => {
    chrome.storage.local.get(["dev_creds"], async (data) => {
      if (!data.dev_creds || !data.dev_creds.email || !data.dev_creds.password) {
        resolve(false);
        return;
      }
      try {
        const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
          method: "POST",
          headers: {
            "apikey": SUPABASE_ANON,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email: data.dev_creds.email, password: data.dev_creds.password }),
        });
        if (!res.ok) { console.error("devAutoLogin failed: HTTP " + res.status); resolve(false); return; }
        const json = await res.json();
        if (!json.access_token || !json.user) { console.error("devAutoLogin failed: no access_token in response"); resolve(false); return; }
        currentToken = json.access_token;
        currentRefresh = json.refresh_token || null;
        currentUser = {
          id:    json.user.id,
          email: json.user.email,
          name:  (json.user.user_metadata && json.user.user_metadata.name) || json.user.email,
        };
        chrome.storage.local.set({ sb_token: currentToken, sb_refresh: currentRefresh, sb_user: currentUser });
        resolve(true);
      } catch (err) { console.error("devAutoLogin error:", err); resolve(false); }
    });
  });
}

async function loadSession() {
  return new Promise(resolve => {
    chrome.storage.local.get(["sb_token", "sb_user", "sb_refresh"], async (data) => {
      if (data.sb_token && data.sb_user) {
        currentToken   = data.sb_token;
        currentUser    = data.sb_user;
        currentRefresh = data.sb_refresh || null;
        resolve(true);
      } else {
        resolve(await devAutoLogin());
      }
    });
  });
}

// Check token validity before every API call
async function ensureValidToken() {
  if (!currentToken) {
    if (!(await devAutoLogin())) { goTo(pageLogin); return false; }
  }
  if (tokenExpiresSoon(currentToken)) {
    const ok = await silentRefresh();
    if (!ok) return false;
  }
  return true;
}

// Proactive background refresh — check every 4 minutes
setInterval(async () => {
  if (!currentToken) return;
  if (tokenExpiresSoon(currentToken)) {
    await silentRefresh();
  }
}, 4 * 60 * 1000);

async function fetchProfile() {
  if (!currentToken || !currentUser) return;
  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/users?id=eq.${currentUser.id}&select=tier,essay_count`,
      {
        headers: {
          "apikey":        SUPABASE_ANON,
          "Authorization": `Bearer ${currentToken}`,
        }
      }
    );
    const rows = await res.json();
    if (rows && rows.length > 0) {
      currentTier = rows[0].tier || "free";
      essayCount  = rows[0].essay_count || 0;
    } else {
      // Row doesn't exist yet — create it
      await fetch(`${SUPABASE_URL}/rest/v1/users`, {
        method: "POST",
        headers: {
          "apikey":        SUPABASE_ANON,
          "Authorization": `Bearer ${currentToken}`,
          "Content-Type":  "application/json",
          "Prefer":        "return=minimal",
        },
        body: JSON.stringify({
          id:    currentUser.id,
          email: currentUser.email,
          tier:  "free",
          essay_count: 0,
        })
      });
      currentTier = "free";
      essayCount  = 0;
    }
  } catch (err) {
    console.error("fetchProfile error:", err);
  }
}

async function incrementEssayCount() {
  if (!currentToken || !currentUser) return;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/rpc/increment_essay_count`, {
      method: "POST",
      headers: {
        "apikey":        SUPABASE_ANON,
        "Authorization": `Bearer ${currentToken}`,
        "Content-Type":  "application/json",
      },
      body: JSON.stringify({ user_id: currentUser.id })
    });
    essayCount++;
    updateUserBar();
  } catch (err) {
    console.error("incrementEssayCount error:", err);
  }
}

// ─────────────────────────────────────────────
//  AUTH — USER BAR & TIER UI
// ─────────────────────────────────────────────
function updateUserBar() {
  if (!currentUser) { userBar.style.display = "none"; return; }

  userBar.style.display    = "flex";
  userAvatar.textContent   = (currentUser.email || "?")[0].toUpperCase();
  userEmailEl.textContent  = currentUser.email || "";

  const limits = TIER_LIMITS[currentTier] || TIER_LIMITS.free;
  const maxE   = limits.essays;
  const usedPct = maxE === Infinity ? 0 : essayCount / maxE;

  // Essay usage chip
  if (maxE === Infinity) {
    essayUsageEl.textContent = `${essayCount} essays`;
    essayUsageEl.className   = "essay-usage";
  } else {
    essayUsageEl.textContent = `${essayCount} / ${maxE}`;
    essayUsageEl.className   = "essay-usage" +
      (usedPct >= 1 ? " usage-full" : usedPct >= 0.8 ? " usage-warn" : "");
  }

  // Tier badge
  tierBadgeEl.textContent = currentTier.charAt(0).toUpperCase() + currentTier.slice(1);
  tierBadgeEl.className   = `tier-badge tier-badge-${currentTier}`;

  // Upgrade button — hide for unlimited
  upgradeBtnEl.style.display = currentTier === "unlimited" ? "none" : "flex";

  applyTierGating();
}

function applyTierGating() {
  const limits  = TIER_LIMITS[currentTier] || TIER_LIMITS.free;
  const isFree  = currentTier === "free";
  const atLimit = limits.essays !== Infinity && essayCount >= limits.essays;

  // Word count crown
  wordCountCrown.classList.toggle("tier-hidden", !isFree);

  // WPM crown (on preview page)
  wpmCrown.classList.toggle("tier-hidden", !isFree);

  // Outline toggle — lock for free
  if (isFree) {
    outlineCrown.classList.remove("tier-hidden");
    outlineToggle.classList.add("locked");
    if (outlineOn) {
      outlineOn = false;
      outlineSw.classList.remove("on");
      outlineToggle.classList.remove("on");
    }
  } else {
    outlineCrown.classList.add("tier-hidden");
    outlineToggle.classList.remove("locked");
  }

  // Generate button — upgrade state when at essay limit
  if (atLimit) {
    genBtn.textContent = "👑 Upgrade to Generate More →";
    genBtn.classList.add("gen-btn-upgrade");
  } else {
    genBtn.textContent = "Generate →";
    genBtn.classList.remove("gen-btn-upgrade");
  }
}

// ─────────────────────────────────────────────
//  BOOT
// ─────────────────────────────────────────────
(async () => {
  const hasSession = await loadSession();
  if (!hasSession) {
    goTo(pageLogin);
    return;
  }
  await fetchProfile();
  updateUserBar();
  goTo(pageForm);
})();

// Listen for token arriving after login
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.sb_token && changes.sb_token.newValue) {
    chrome.storage.local.get(['sb_token', 'sb_user', 'sb_refresh'], async (data) => {
      if (data.sb_token && data.sb_user) {
        currentToken   = data.sb_token;
        currentUser    = data.sb_user;
        currentRefresh = data.sb_refresh || null;
        await fetchProfile();
        updateUserBar();
        goTo(pageForm);
      }
    });
  }
});

// ─────────────────────────────────────────────
//  LOGIN BUTTON
// ─────────────────────────────────────────────
loginBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: "https://getscrybe.net/login.html" });
});

// ─────────────────────────────────────────────
//  UPGRADE BUTTON
// ─────────────────────────────────────────────
upgradeBtnEl.addEventListener("click", () => {
  chrome.tabs.create({ url: "https://getscrybe.net/purchase.html" });
});

// ─────────────────────────────────────────────
//  PASTE & TYPE SHORTCUT
// ─────────────────────────────────────────────
document.getElementById("pasteTypeBtn").addEventListener("click", () => {
  goToPreview(pageForm);
  setTimeout(() => {
    document.getElementById("tabCustom").click();
    document.getElementById("customText").focus();
  }, 50);
});

// ─────────────────────────────────────────────
//  SUBJECT
// ─────────────────────────────────────────────
subjectEl.addEventListener("change", () => {
  if (subjectEl.value === "other") {
    otherWrap.classList.add("visible");
    otherSubjectEl.focus();
  } else {
    otherWrap.classList.remove("visible");
  }
});

function getSubject() {
  if (subjectEl.value === "other") return otherSubjectEl.value.trim() || "Other";
  return subjectEl.value || "General";
}

// ─────────────────────────────────────────────
//  NUMERIC GUARDS
// ─────────────────────────────────────────────
function enforceNumeric(el, min, max) {
  el.addEventListener("keydown", (e) => {
    const allowed = ["Backspace","Delete","Tab","ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"];
    if (allowed.includes(e.key)) return;
    if (!/^\d$/.test(e.key)) e.preventDefault();
  });
  el.addEventListener("input", () => {
    let raw = el.value.replace(/\D/g, "");
    const maxLen = String(max).length;
    if (raw.length > maxLen) raw = raw.slice(0, maxLen);
    if (raw !== "" && parseInt(raw) > max) raw = String(max);
    el.value = raw;
  });
  el.addEventListener("blur", () => {
    const v = parseInt(el.value);
    if (!isNaN(v) && v < min) el.value = String(min);
  });
}

enforceNumeric(wordCountEl, 50, 99999);
enforceNumeric(wpmEl, 1, 800);

// Cap word count for free tier on blur/input
wordCountEl.addEventListener("change", enforceTierWordCap);
wordCountEl.addEventListener("blur",   enforceTierWordCap);

function enforceTierWordCap() {
  const limits = TIER_LIMITS[currentTier] || TIER_LIMITS.free;
  if (limits.maxWords === Infinity) return;
  const val = parseInt(wordCountEl.value);
  if (!isNaN(val) && val > limits.maxWords) {
    wordCountEl.value = String(limits.maxWords);
    flashElement(wordCountEl, "input-cap-flash");
    flashElement(wordCountCrown, "lock-flash");
  }
}

// Cap WPM for free tier on blur/input
wpmEl.addEventListener("change", enforceTierWpmCap);
wpmEl.addEventListener("blur",   enforceTierWpmCap);

function enforceTierWpmCap() {
  const limits = TIER_LIMITS[currentTier] || TIER_LIMITS.free;
  if (limits.maxWpm === Infinity) return;
  const val = parseInt(wpmEl.value);
  if (!isNaN(val) && val > limits.maxWpm) {
    wpmEl.value = String(limits.maxWpm);
    flashElement(wpmEl, "input-cap-flash");
    flashElement(wpmCrown, "lock-flash");
  }
}

function flashElement(el, cls) {
  el.classList.remove(cls);
  void el.offsetWidth; // reflow to restart animation
  el.classList.add(cls);
  setTimeout(() => el.classList.remove(cls), 750);
}

// ─────────────────────────────────────────────
//  OUTLINE TOGGLE
// ─────────────────────────────────────────────
let outlineOn = false;

outlineToggle.addEventListener("click", () => {
  const isFree = currentTier === "free";
  if (isFree) {
    // Flash the crown and open upgrade page
    flashElement(outlineCrown, "lock-flash");
    chrome.tabs.create({ url: "https://getscrybe.net/purchase.html" });
    return;
  }
  outlineOn = !outlineOn;
  outlineSw.classList.toggle("on", outlineOn);
  outlineToggle.classList.toggle("on", outlineOn);
});

// ─────────────────────────────────────────────
//  VALIDATION
// ─────────────────────────────────────────────
function markError(el) {
  el.classList.add("input-error");
  el.addEventListener("input",  () => el.classList.remove("input-error"), { once: true });
  el.addEventListener("change", () => el.classList.remove("input-error"), { once: true });
}

function validate() {
  let hasError = false;
  if (!subjectEl.value)                                             { markError(subjectEl);      hasError = true; }
  if (subjectEl.value === "other" && !otherSubjectEl.value.trim()) { markError(otherSubjectEl); hasError = true; }
  if (!parseInt(wordCountEl.value))                                 { markError(wordCountEl);    hasError = true; }
  if (!instructionsEl.value.trim())                                 { markError(instructionsEl); hasError = true; }
  return !hasError;
}

// ─────────────────────────────────────────────
//  BUILD PROMPT
// ─────────────────────────────────────────────
function gradeLevelGuide(level) {
  const guides = {
    "9":       "9th-grade level: keep it simple; clear, direct sentences; everyday academic vocabulary; short paragraphs; avoid rare or fancy words.",
    "10":      "10th-grade level: straightforward academic vocabulary; mostly simple-to-medium sentences with a few complex ones.",
    "11":      "11th-grade level: solid academic vocabulary; varied sentence lengths; comfortable complex sentences; some subject-specific terms.",
    "12":      "12th-grade level: strong academic vocabulary; confident complex sentences; precise wording; mature but not ornate.",
    "college": "College level: sophisticated, precise vocabulary; full range of sentence structures; nuanced and confident academic writing.",
  };
  return guides[level] || guides["college"];
}

// Auto-picked per humanize variant, so best-of-N scoring also picks the style.
const WRITING_STYLES = [
  {
    name: "Direct and argumentative",
    desc: "This writer takes a clear stance early and defends it forcefully. Sentences lean shorter; claims are stated plainly (\"the data does not support that view\"), and counterpoints are dismissed rather than entertained. Word choices are exact but never fancy. A few paragraphs run long, others are short.",
  },
  {
    name: "Measured and analytical",
    desc: "A careful, even-handed writer. Weighs both sides before concluding, hedges honestly (\"the evidence mostly points to\", \"on balance\"), and mixes long deliberate sentences with short ones. Reaches for concrete details and qualified claims over absolutes.",
  },
  {
    name: "Concise and plainspoken",
    desc: "Gets straight to the point and stays there. Short paragraphs, plain words, minimal ornament. Often skips transitions altogether or uses \"so\", \"but\", \"then\". Sounds like someone who wants the draft done but still makes the argument clearly.",
  },
  {
    name: "Personal and reflective",
    desc: "First-person and a little introspective. Uses \"I think\", \"what stood out to me\", and occasional informal asides. Reaches for the exact word, mixes precise academic terms with everyday ones, and is comfortable saying what surprised or bothered them.",
  },
  {
    name: "Scholarly but natural",
    desc: "Keeps a formal academic register with natural human rhythm: varied sentence lengths, plain phrasing where possible, no stiffness. Reads like a strong paper written in one sitting by a real person, not a template.",
  },
];

function styleGuide(style) {
  return `Writing style — ${style.name}: ${style.desc}`;
}

function buildPrompt(includeOutline) {
  const subject      = getSubject();
  const grade        = document.getElementById("grade").value;
  const gradeLevel   = gradeLevelEl.value;
  const wordCount    = parseInt(wordCountEl.value);
  const rubric       = rubricEl.value.trim();
  const instructions = instructionsEl.value.trim();
  const lines = [];

  lines.push(`You are an expert academic writer. Write a high quality ${grade}-level essay on the following for the subject: ${subject}.`);
  lines.push("");

  if (instructions) {
    lines.push("## Assignment Instructions");
    lines.push(instructions);
    lines.push("");
  }

  if (rubric) {
    lines.push("## Rubric / Grading Criteria");
    lines.push("Address every criterion listed below thoroughly:");
    lines.push(rubric);
    lines.push("");
  }

  if (includeOutline) {
    lines.push("## Format");
    lines.push("First write a structured outline with Roman numerals (Introduction, Body points, Conclusion).");
    lines.push("Then write the separator exactly: ---ESSAY---");
    lines.push("Then write the full essay.");
    lines.push("");
  }

  lines.push("## Requirements");
  lines.push(`- Write about ${wordCount} words. The hard maximum is ${wordCount} words — do not exceed it.`);
  lines.push(`- Grade target: ${grade}`);
  lines.push(`- ${gradeLevelGuide(gradeLevel)}`);
  lines.push(`- Strong thesis statement in the introduction`);
  lines.push(`- Each body paragraph must have a clear topic sentence, evidence, and analysis`);
  lines.push(`- Use subject-specific vocabulary and examples relevant to ${subject}`);
  lines.push(`- Formal academic tone throughout`);
  lines.push(`- No bullet points or headers in the essay itself`);
  lines.push(`- Conclusion must synthesize the argument, not just restate it`);
  lines.push(`- Plain text only, no markdown, no bold, no italics, no asterisks`);

  return lines.join("\n");
}

// ─────────────────────────────────────────────
//  DEEPSEEK CALL
// ─────────────────────────────────────────────
async function callDeepSeek(prompt, temperature = 0.7) {
  const valid = await ensureValidToken();
  if (!valid) throw new Error("Session expired — please sign in again.");
  const response = await fetch(
    `${SUPABASE_URL}/functions/v1/generate-essay`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${currentToken}`,
      },
      body: JSON.stringify({ prompt, temperature }),
    }
  );
  const raw = await response.text();
  if (!response.ok) throw new Error(`Server error ${response.status}: ${raw}`);
  return JSON.parse(raw).choices[0].message.content
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/\*(.*?)\*/g, "$1");
}

// ─────────────────────────────────────────────
//  AI-TELL ANALYZER + BEST-OF-N HUMANIZER
//  Detection signals grounded in the published
//  AI-detection literature (perplexity, burstiness,
//  hedge density, transition fingerprint, structural
//  tells). Rules ported from MIT-licensed projects:
//  blader/humanizer, harshaneel/humanize (50+ sources),
//  imsv1301/unmask-ai, brandonwise/humanizer
// ─────────────────────────────────────────────

const AI_TELL_WORDS = [
  // core AI vocabulary
  "delve", "delving", "leverage", "leveraged", "leveraging", "utilize", "utilizing",
  "robust", "comprehensive", "streamline", "streamlining", "foster", "fostered",
  "fostering", "facilitate", "facilitating", "pivotal", "nuanced", "multifaceted",
  "enduring", "garner", "vibrant", "tapestry", "tapestries", "testament", "interplay",
  "intricate", "intricacies", "showcase", "showcased", "showcasing", "underscore",
  "underscores", "underscored", "underscoring", "transformative", "paradigm", "synergy",
  "holistic", "seamless", "seamlessly", "cutting-edge", "state-of-the-art", "elevate",
  "elevating", "embark", "embarking", "realm", "navigate", "navigating", "ever-evolving",
  "meticulous", "profound", "deeply rooted", "evolving landscape", "landscape of",
  "in the realm of", "a myriad of", "a plethora of", "sets the stage", "focal point",
  "indelible mark", "key turning point", "setting the stage",
  // hedge / softener clusters
  "it is important to note", "it is worth noting", "it is worth mentioning", "notably",
  "in many cases", "generally speaking", "it can be argued",
  // filler / formula openers and closers
  "in today's", "in today’s", "in conclusion", "in summary", "to summarize",
  "it goes without saying", "needless to say", "at the end of the day", "at its core",
  "turns out", "it turns out that",
  // AI transition fingerprint
  "furthermore", "moreover", "additionally", "it is clear that", "this highlights",
  "this underscores", "as previously mentioned",
  // promotional register
  "breathtaking", "must-visit", "stunning", "boasts a rich", "renowned for",
  "groundbreaking", "nestled in the heart of", "in the heart of",
  // persuasive authority tropes
  "the real question is", "what really matters", "fundamentally", "the deeper issue",
  "the heart of the matter", "in reality",
];

const AI_TELL_PATTERNS = [
  ["em dash", /\u2014/g, 2],
  ["negation framing ('not X, it's Y')", /\bnot (just|about|merely)\b[^.!?]{1,70}\bit['\u2019]s\b/gi, 2],
  ["negation framing ('it's not X, it's Y')", /\bit['\u2019]s not (about|just)\b[^.!?]{1,70}\b(it['\u2019]s|but)\b/gi, 2],
  ["'-ing' padding", /\b(highlighting|underscoring|emphasizing|symbolizing|ensuring|reflecting|showcasing|fostering|cultivating|contributing to|exemplifying)\b/gi, 1],
  ["rhetorical opener", /^(in today['\u2019]s|when it comes to|it is important to note|it is worth noting|undoubtedly|in the ever-evolving|in this essay|this essay will)/im, 1],
  ["signpost phrase", /\b(dive into|let['\u2019]s dive in|goes without saying|as we delve|last but not least|without further ado)\b/gi, 1],
  ["significance padding", /\b(is|serves as|stands as|plays)\s+(a\s+|as\s+)?(crucial|vital|key|pivotal|essential|significant)\s+(role|moment|part)\b/gi, 2],
  ["transition opener", /^(furthermore|moreover|additionally|in addition|on the other hand)\s*,/gim, 2],
  ["'this + highlight/underscore'", /\bthis\s+(highlights|underscores|demonstrates|emphasizes)\s+the\s+importance\b/gi, 2],
  ["legacy verdict ('that legacy matters')", /\blegacy (matters|mattered)\b/gi, 2],
  ["significance verdict ('matters enormously')", /\b(matters|mattered) enormously\b/gi, 2],
  ["'real and transformative' verdict", /\b(was|were) real and (transformative|profound|significant|meaningful|lasting)\b/gi, 2],
  ["verdict clause ('that showed just how limited')", /\bthat (showed|shows|proves|proved|demonstrates|demonstrated|highlighted|underscored)( just)? how (limited|important|powerful|significant)\b/gi, 2],
  ["moral-power cliché", /\bmoral (power|weight|authority|force)\b/gi, 2],
];

const CONNECTOR_WORDS = [
  "however", "therefore", "thus", "consequently", "nevertheless", "furthermore",
  "moreover", "additionally", "in addition", "in conclusion", "as a result",
  "for instance", "for example",
];

const HEDGE_WORDS = [
  "often", "generally", "typically", "in many cases", "it can be argued",
  "can often", "may lead to", "tends to", "one might", "it is possible that",
];

const HUMANIZE_VARIANTS = 3;
const HUMANIZE_MAX_FIX_ROUNDS = 2;
const HUMANIZE_FIX_THRESHOLD = 5;
const HUMANIZE_MIN_COV = 0.30;

function sentenceLengths(text) {
  return text
    .split(/[.!?]+/)
    .map(s => s.trim())
    .filter(Boolean)
    .map(s => s.split(/\s+/).filter(Boolean).length);
}

function burstinessCoV(lengths) {
  if (lengths.length < 4) return 0.5;
  const mean = lengths.reduce((a, b) => a + b, 0) / lengths.length;
  if (!mean) return 0;
  const variance = lengths.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / lengths.length;
  return Math.sqrt(variance) / mean;
}

function countSimilarRuns(lengths) {
  let runs = 0;
  for (let i = 0; i + 2 < lengths.length; i++) {
    if (Math.abs(lengths[i] - lengths[i + 1]) <= 5 &&
        Math.abs(lengths[i + 1] - lengths[i + 2]) <= 5) runs++;
  }
  return runs;
}

function sentenceOpenerDiversity(text) {
  const openers = text.split(/[.!?]+/)
    .map(s => s.trim())
    .filter(Boolean)
    .map(s => (s.split(/\s+/)[0] || "").toLowerCase().replace(/[^a-z]/g, ""));
  if (!openers.length) return 1;
  return new Set(openers).size / openers.length;
}

function textMentions(low, phrase) {
  if (/[ \u2019'-]/.test(phrase) || phrase.includes(".")) return low.includes(phrase);
  return new RegExp("\\b" + phrase + "\\b").test(low);
}

function countOccurrences(low, list) {
  let n = 0;
  list.forEach(phrase => {
    if (/[ \u2019'-]/.test(phrase) || phrase.includes(".")) {
      let i = low.indexOf(phrase);
      while (i !== -1) { n++; i = low.indexOf(phrase, i + 1); }
    } else {
      const m = low.match(new RegExp("\\b" + phrase + "\\b", "g"));
      if (m) n += m.length;
    }
  });
  return n;
}

function repeatedTrigrams(low) {
  const words = low.split(/\s+/)
    .map(w => w.replace(/[^a-z]/g, ""))
    .filter(Boolean);
  const seen = new Set();
  let reps = 0;
  for (let i = 0; i + 2 < words.length; i++) {
    const key = words[i] + " " + words[i + 1] + " " + words[i + 2];
    if (seen.has(key)) reps++;
    else seen.add(key);
  }
  return reps;
}

function analyzeHumanTells(text) {
  const low = text.toLowerCase();
  const lengths = sentenceLengths(text);
  const wordCount = text.split(/\s+/).filter(Boolean).length;

  const wordHits = AI_TELL_WORDS.filter(w => textMentions(low, w));

  const patternHits = [];
  AI_TELL_PATTERNS.forEach(([name, re, weight]) => {
    const matches = text.match(re);
    if (matches && matches.length) patternHits.push({ name, count: matches.length, weight });
  });

  const connectorCount = countOccurrences(low, CONNECTOR_WORDS);
  const hedgeCount = countOccurrences(low, HEDGE_WORDS);
  const cov = burstinessCoV(lengths);
  const similarRuns = countSimilarRuns(lengths);
  const openerDiversity = sentenceOpenerDiversity(text);
  const trigramReps = repeatedTrigrams(low);

  let score = 0;
  score += wordHits.length;
  score += patternHits.reduce((a, p) => a + p.weight * p.count, 0);
  if (connectorCount >= 3) score += connectorCount - 2;
  if (hedgeCount >= 2) score += hedgeCount - 1;
  if (cov < HUMANIZE_MIN_COV) score += 2;
  if (wordCount >= 150 && similarRuns >= 3) score += 2;
  if (wordCount >= 150 && !lengths.some(l => l < 8)) score += 2;
  if (wordCount >= 80 && openerDiversity < 0.5) score += 2;
  if (trigramReps > 0) score += 1;

  return {
    score, cov, wordHits, patternHits,
    connectorCount, hedgeCount, similarRuns, openerDiversity, trigramReps,
    lengths, wordCount,
  };
}

// ─────────────────────────────────────────────
//  HUMANIZE — best-of-N rewrite + verify loop
// ─────────────────────────────────────────────

// Deterministic cleanup applied to every final essay: no dashes, no huge words.
const SIMPLIFY_MAP = {
  "utilize": "use", "utilizes": "uses", "utilizing": "using", "utilized": "used",
  "subsequently": "then", "consequently": "so", "therefore": "so", "thus": "so",
  "nevertheless": "still", "nonetheless": "still", "moreover": "also",
  "furthermore": "also", "additionally": "also",
  "demonstrate": "show", "demonstrates": "shows", "demonstrated": "showed", "demonstrating": "showing",
  "obtain": "get", "obtains": "gets", "obtained": "got", "obtaining": "getting",
  "numerous": "many", "commence": "start", "commences": "starts", "commenced": "started",
  "commencing": "starting", "endeavor": "try", "endeavors": "tries", "endeavored": "tried",
  "endeavoring": "trying", "pivotal": "key", "crucial": "key", "vital": "key",
  "essential": "key", "paramount": "key", "facilitate": "help", "facilitates": "helps",
  "facilitating": "helping", "facilitated": "helped", "meticulous": "careful",
  "profound": "deep", "cognizant": "aware", "imperative": "important",
  "fundamental": "basic", "substantial": "big",
};

function stripDashes(text) {
  return text
    .replace(/\s*[\u2014\u2013]\s*/g, ", ")
    .replace(/([A-Za-z])\s+-\s+(?=[A-Za-z])/g, "$1, ")
    .replace(/\s*,(\s*,)+/g, ",")
    .replace(/\s*,([.!?])/g, "$1")
    .trim();
}

function simplifyVocabulary(text) {
  text = text.replace(/\bin addition\b/gi, m => /^[A-Z]/.test(m) ? "Also" : "also");
  text = text.replace(/\baforementioned\b/gi, m => /^[A-Z]/.test(m) ? "Mentioned earlier" : "mentioned earlier");
  const out = text.split(/(\s+)/).map(token => {
    if (!/[A-Za-z]/.test(token)) return token;
    const m = token.match(/^([^A-Za-z]*)([A-Za-z][A-Za-z'\u2019-]*)([^A-Za-z]*)$/);
    if (!m) return token;
    const [, pre, word, post] = m;
    const rep = SIMPLIFY_MAP[word.toLowerCase()];
    if (!rep) return token;
    const replaced = /^[A-Z]/.test(word) ? rep.charAt(0).toUpperCase() + rep.slice(1) : rep;
    return pre + replaced + post;
  });
  return out.join("");
}

function postProcessEssay(text) {
  return simplifyVocabulary(stripDashes(text));
}

// LLMs routinely overshoot word counts, so enforce the limit deterministically.
// Truncates at a sentence boundary when possible; hard-cuts only as a fallback.
function capWordCount(text, maxWords) {
  if (!text) return text;
  if (!maxWords || maxWords <= 0) return text;
  const wordList = text.trim().split(/\s+/).filter(Boolean);
  if (wordList.length <= maxWords) return text.trim().replace(/[ \t]{2,}/g, " ");

  const sentences = text.match(/[^.!?]+[.!?]*\s*/g) || [text];
  let out = "";
  let count = 0;
  for (const s of sentences) {
    const n = s.split(/\s+/).filter(Boolean).length;
    if (count + n > maxWords) break;
    out += s;
    count += n;
  }
  out = out.trim().replace(/[ \t]{2,}/g, " ");
  if (out) return out;
  return wordList.slice(0, maxWords).join(" ");
}

function buildHumanizePrompt(draft, gradeLevel, style) {
  return `Rewrite this essay so it reads like one real person wrote it in a single sitting — not generated text — while keeping the original content intact. Use this writing style:

${styleGuide(style)}

Grade: ${gradeLevelGuide(gradeLevel)}

The result must also score as human on AI-writing detectors (GPTZero / Turnitin-style), which measure perplexity (how predictable each word is), burstiness (how varied sentence lengths are), and look for AI vocabulary, formulaic structure, and uniform rhythm.

Keep the style's voice consistent across the whole essay — every paragraph should sound like the same mind produced it. Vary the architecture from paragraph to paragraph: do not build more than one or two paragraphs on the exact same topic-sentence-to-evidence-to-analysis-to-link shape, and vary paragraph lengths (one short, 3-5 sentence paragraph is fine and human). Sometimes open a paragraph with the concrete detail, a question, or a plain claim instead of the topic sentence.

Hard rules (never break these):
- Keep the core arguments, thesis, evidence, and every fact exactly the same. Never invent facts, quotes, names, numbers, or citations.
- Keep the word count the same as the original essay. Never exceed the original essay's word count.
- No em dashes (—) at all. Never use dashes to separate clauses.
- No "not just X, it's Y" or "it's not about X, it's about Y" framing. Say what something IS, not what it ISN'T.
- No AI-vocabulary words or phrases: delve, leverage, utilize, robust, comprehensive, streamline, foster, facilitate, pivotal, nuanced, multifaceted, testament, tapestry, showcase, underscore, furthermore, moreover, additionally, "in conclusion", "in today's", "it is important to note", "it is worth noting", "dive into", "plays a crucial role", "this highlights", "not only X but also Y".
- Ban these formulaic openers: "One of the most", "This essay will", "In today's society", "In conclusion", "To conclude", "Overall," (as a paragraph opener), "It is important to note that", "plays a crucial/important/significant role".
- Ban significance-verdict sentences that only exist to pronounce how important or lasting something was: "the victories were real and transformative", "that legacy matters enormously", "this showed just how limited legislative change can be", "these were fundamental changes", "a landmark moment". To show something mattered, name a concrete consequence (a number, a law, a reaction, a before-and-after) instead of pronouncing a verdict.
- Avoid tag-on verdict clauses glued with "and" or "but" (e.g. "X proved real economic and moral power, and that energy pushed the victories forward"). If a clause only adds a verdict, cut the whole clause or split the sentence.
- Avoid moral-power and abstraction clusters ("real economic and moral power", "entrenched poverty", "wielded real power", "dismantled the legal framework").
- Use straight apostrophes only (') — never curly ones.
- Plain text only. No markdown, bold, italics, asterisks, bullet points, or headers.

How to sound human (still guarded by the style):
- Concrete over abstract: whenever you explain what something means, tie it to a specific, plain fact — a number, a name, a date, a concrete action — not a significance verdict. Prefer the Human examples over the AI ones:
  AI: "The legal and political victories were real and transformative."
  Human: "Black voter registration in the South shot up."
  AI: "It dismantled the legal framework of segregation, and that legacy matters enormously."
  Human: "You can see the impact in the numbers."
- Default to short, plain sentences (under ~18 words) when they carry the point. Split most compound sentences joined by "and" or "but" into two. A few long sentences are fine, but long-and-abstract is not.
- Word choice (perplexity): pick unexpected-but-natural words, not the safest generic option. Replace vague fillers like "significant", "important", "various", "many" with something specific to the essay. A person reaches for the precise word, and sometimes an ordinary one.
- Rhythm (burstiness): vary sentence length a lot. No 3 consecutive sentences within 5 words of the same length. Every ~150-word stretch needs at least one very short sentence (under 8 words) and at least one long one (over 30 words). Vary how sentences START — do not begin several sentences in a row with "The", "This", "It", or "One".
- Let a handful of small imperfections, informal moments, and personal reactions appear naturally wherever they fit — do not manufacture them mechanically in one spot.
- Hedge only when genuinely uncertain; assert claims directly, as the style allows.
- Use at most two transition words like "however", "therefore", "so", "in addition" across the whole essay. Connect with "but", "so", "then", or nothing.
- Make the conclusion land naturally — even slightly unfinished — rather than announcing it.

After the rewritten essay, add a line containing exactly ---AUDIT---, then list any AI-tells still remaining in your rewrite (banned words, em dashes, negation framing, significance or legacy verdicts, uniform sentence rhythm, repeated openers, overused transitions, formulaic paragraph shapes). If none remain, write "none".

Essay to rewrite:
${draft}`;
}

function buildFixPrompt(essay, analysis, extraAudit) {
  const items = [];
  if (analysis.wordHits.length) items.push("Banned AI words: " + analysis.wordHits.join(", "));
  analysis.patternHits.forEach(p => items.push("Pattern \"" + p.name + "\" appears " + p.count + "x"));
  if (analysis.connectorCount >= 3) items.push("Too many transition words (" + analysis.connectorCount + " total: however/therefore/furthermore/moreover/additionally etc.). Keep at most 2.");
  if (analysis.hedgeCount >= 2) items.push("Too many hedges (" + analysis.hedgeCount + "): often/generally/typically/it can be argued. Assert directly.");
  if (analysis.cov < HUMANIZE_MIN_COV) items.push("Sentence rhythm too uniform (length variation coefficient " + analysis.cov.toFixed(2) + "; human range is roughly 0.4-0.8). Vary sentence lengths.");
  if (analysis.wordCount >= 150 && analysis.similarRuns >= 3) items.push(analysis.similarRuns + " groups of 3+ consecutive sentences have similar lengths. Break up the rhythm.");
  if (analysis.wordCount >= 150 && !analysis.lengths.some(l => l < 8)) items.push("No short sentences anywhere. Add at least one short sentence or fragment.");
  if (analysis.wordCount >= 80 && analysis.openerDiversity < 0.5) items.push("Too many sentences start the same way (opener variety " + analysis.openerDiversity.toFixed(2) + "). Vary sentence openings.");
  if (analysis.trigramReps > 0) items.push("A 3-word phrase is repeated. Remove the repetition.");
  if (extraAudit) items.push("Model audit: " + extraAudit);
  return [
    "Fix ONLY the AI-tells listed below in the essay. Do not change facts, arguments, thesis, or the overall word count. Keep the current voice and style.",
    "Remaining AI-tells:",
    ...items.map(i => "- " + i),
    "Return only the corrected essay, plain text, nothing else. No markdown, no headers, no bullets.",
    "Essay:",
    essay,
  ].join("\n");
}

function splitEssayAndAudit(raw) {
  const parts = raw.split(/\s*-{2,}\s*AUDIT\s*-{2,}\s*/i);
  const essay = parts.length > 1 ? (parts[0] || "").trim() : raw.trim();
  const audit = parts.length > 1 && !/^none$/i.test((parts[1] || "").trim())
    ? (parts[1] || "").trim()
    : "";
  return { essay, audit };
}

async function humanize(draft, gradeLevel, maxWords) {
  // Best-of-N: generate variants in parallel, score each locally, ship the best.
  const temps = [0.8, 0.9, 1.0];
  const variants = await Promise.all(
    temps.slice(0, HUMANIZE_VARIANTS).map(t => {
      const style = WRITING_STYLES[Math.floor(Math.random() * WRITING_STYLES.length)];
      return callDeepSeek(buildHumanizePrompt(draft, gradeLevel, style), t)
        .then(splitEssayAndAudit)
        .catch(() => null);
    })
  );

  let best = null;
  variants.forEach(candidate => {
    if (!candidate || !candidate.essay) return;
    candidate.analysis = analyzeHumanTells(candidate.essay);
    if (!best || candidate.analysis.score < best.analysis.score) best = candidate;
  });

  const draftWords = draft.split(/\s+/).filter(Boolean).length;
  const isDegenerate = !best || !best.essay
    || best.essay.split(/\s+/).filter(Boolean).length < Math.max(20, Math.floor(draftWords * 0.6));

  // Never ship a failed or gutted variant — fall back to the original draft.
  if (isDegenerate) {
    best = { essay: draft, audit: "", analysis: analyzeHumanTells(draft) };
  }

  let essay = best.essay;
  let analysis = best.analysis;
  let extraAudit = best.audit;

  for (let i = 0; i < HUMANIZE_MAX_FIX_ROUNDS; i++) {
    const hasEmDash = analysis.patternHits.some(p => p.name === "em dash");
    if (analysis.score < HUMANIZE_FIX_THRESHOLD && !hasEmDash) break;

    const currentWords = essay.split(/\s+/).filter(Boolean).length;
    const fixed = (await callDeepSeek(buildFixPrompt(essay, analysis, extraAudit), 0.7))
      .split(/\s*-{2,}\s*AUDIT\s*-{2,}\s*/i)[0].trim();

    const fixedWords = fixed.split(/\s+/).filter(Boolean).length;
    if (!fixed || fixedWords < Math.max(20, Math.floor(currentWords * 0.6))) break;

    essay = fixed;
    extraAudit = "";
    analysis = analyzeHumanTells(essay);
  }

  // Guaranteed cleanup: no dashes, no huge words, no matter what the model did.
  return capWordCount(postProcessEssay(essay), maxWords);
}

// ─────────────────────────────────────────────
//  OVERLAY HELPERS
// ─────────────────────────────────────────────
function showOverlay(el, title) {
  el.querySelector(".gen-overlay-title").textContent = title;
  el.classList.add("active");
}

function hideOverlay(el) {
  el.classList.remove("active");
}

// ─────────────────────────────────────────────
//  GENERATE BUTTON
// ─────────────────────────────────────────────
genBtn.addEventListener("click", async () => {
  // If at essay limit, clicking goes to upgrade
  const limits  = TIER_LIMITS[currentTier] || TIER_LIMITS.free;
  const atLimit = limits.essays !== Infinity && essayCount >= limits.essays;
  if (atLimit) {
    chrome.tabs.create({ url: "https://getscrybe.net/purchase.html" });
    return;
  }

  if (!validate()) return;

  // Enforce word count cap before generating
  const requestedWords = parseInt(wordCountEl.value);
  if (limits.maxWords !== Infinity && requestedWords > limits.maxWords) {
    wordCountEl.value = String(limits.maxWords);
    flashElement(wordCountEl, "input-cap-flash");
    flashElement(wordCountCrown, "lock-flash");
    return;
  }

  genBtn.disabled = true;

  // Show loading UI before the slow API call:
  // outline flow → navigate straight to the outline page with shimmer lines;
  // direct-draft flow → skeleton card overlay.
  if (outlineOn) {
    goTo(pageOutline);
    renderSkeletonLines(outlineBox, 7);
  } else {
    showSkeletonOverlay("Writing draft…");
  }

  try {
    if (outlineOn) {
      const raw         = await callDeepSeek(buildPrompt(true), 0.7);
      const parts       = raw.split(/---ESSAY---/i);
      const outlineText = parts[0].trim();
      const draftText   = parts.length > 1 ? parts[1].trim() : raw;

      outlineBox.innerHTML = "";
      outlineText.split("\n").forEach(line => {
        if (!line.trim()) return;
        const p = document.createElement("p");
        p.className = "outline-line";
        p.textContent = line;
        outlineBox.appendChild(p);
      });

      draftTextEl.value = capWordCount(draftText, requestedWords);
    } else {
      const draft = await callDeepSeek(buildPrompt(false), 0.7);
      draftTextEl.value = capWordCount(draft, requestedWords);
      hideSkeletonOverlay();
      goTo(pageDraft);
    }

    // Increment essay count in Supabase
    await incrementEssayCount();

  } catch (err) {
    hideSkeletonOverlay();
    if (outlineOn) goTo(pageForm);
    console.error(err);
    showToast(err.message, "err");
  } finally {
    genBtn.disabled = false;
  }
});

// ─────────────────────────────────────────────
//  OUTLINE → DRAFT
// ─────────────────────────────────────────────
outlineNextBtn.addEventListener("click", () => {
  goTo(pageDraft);
});

// ─────────────────────────────────────────────
//  APPLY CHANGES
// ─────────────────────────────────────────────
applyBtn.addEventListener("click", async () => {
  const currentDraft = draftTextEl.value.trim();
  const notes        = changesNoteEl.value.trim();

  if (!notes) {
    markError(changesNoteEl);
    changesNoteEl.focus();
    return;
  }

  applyBtn.disabled   = true;
  approveBtn.disabled = true;
  showOverlay(draftOverlay, "Applying changes…");

  try {
    const revisePrompt = `You are editing an academic essay based on the revision notes below.
Revision notes:
${notes}
Rules:
- Apply every requested change faithfully
- Keep the overall word count roughly the same
- Preserve the current essay's existing voice and style throughout — do not make it more formal or more casual than it already is
- Do NOT add markdown, bold, italics, or asterisks
- Return only the revised essay, nothing else
Current essay:
${currentDraft}`;

    const revised = await callDeepSeek(revisePrompt, 0.75);
    draftTextEl.value         = capWordCount(postProcessEssay(revised), parseInt(wordCountEl.value) || undefined);
    changesNoteEl.value       = "";
    changesNoteEl.placeholder = "Changes applied — request more or approve below";
    hideOverlay(draftOverlay);
  } catch (err) {
    hideOverlay(draftOverlay);
    console.error(err);
    showToast(err.message, "err");
  } finally {
    applyBtn.disabled   = false;
    approveBtn.disabled = false;
  }
});

// ─────────────────────────────────────────────
//  APPROVE — humanize then go to preview
// ─────────────────────────────────────────────
approveBtn.addEventListener("click", async () => {
  const draft = draftTextEl.value.trim();
  if (!draft) return;

  approveBtn.disabled = true;
  applyBtn.disabled   = true;
  showOverlay(draftOverlay, "Humanizing…");

  try {
    const essay = await humanize(draft, gradeLevelEl.value, parseInt(wordCountEl.value) || undefined);
    essayEl.value = essay;
    updateWordBadge();
    hideOverlay(draftOverlay);
    goToPreview(pageDraft);
  } catch (err) {
    hideOverlay(draftOverlay);
    console.error(err);
    showToast(err.message, "err");
  } finally {
    approveBtn.disabled = false;
    applyBtn.disabled   = false;
  }
});

// ─────────────────────────────────────────────
//  WORD COUNT BADGE
// ─────────────────────────────────────────────
function updateWordBadge() {
  const words = essayEl.value.trim().split(/\s+/).filter(Boolean).length;
  wordCountBadge.textContent = words.toLocaleString() + " words";
}

essayEl.addEventListener("input", updateWordBadge);

// Custom text word count
const customTextEl         = document.getElementById("customText");
const customWordCountBadge = document.getElementById("customWordCountBadge");

customTextEl.addEventListener("input", () => {
  const words = customTextEl.value.trim().split(/\s+/).filter(Boolean).length;
  customWordCountBadge.textContent = words > 0 ? words.toLocaleString() + " words" : "— words";
});

// ─────────────────────────────────────────────
//  PREVIEW TABS
// ─────────────────────────────────────────────
const tabEssay    = document.getElementById("tabEssay");
const tabCustom   = document.getElementById("tabCustom");
const panelEssay  = document.getElementById("panelEssay");
const panelCustom = document.getElementById("panelCustom");

tabEssay.addEventListener("click", () => {
  tabEssay.classList.add("active");
  tabCustom.classList.remove("active");
  panelEssay.style.display  = "";
  panelCustom.style.display = "none";
});

tabCustom.addEventListener("click", () => {
  tabCustom.classList.add("active");
  tabEssay.classList.remove("active");
  panelEssay.style.display  = "none";
  panelCustom.style.display = "";
});

function getActiveTypingText() {
  const isCustom = tabCustom.classList.contains("active");
  return isCustom ? customTextEl.value : essayEl.value;
}

// ─────────────────────────────────────────────
//  TYPING STATE
// ─────────────────────────────────────────────
function setStatus(text, type) {
  statusEl.textContent = text;
  statusEl.className = type || "";
}

const PAUSE_SVG = '<svg viewBox="0 0 16 16" fill="currentColor"><path d="M5 3h2.6v10H5zM8.4 3H11v10H8.4z"/></svg>';
const PLAY_SVG  = '<svg viewBox="0 0 16 16" fill="currentColor"><path d="M5 3.2l9 4.8-9 4.8z"/></svg>';

let typingPaused = false;

function setPauseState(paused) {
  typingPaused = paused;
  pauseBtn.classList.toggle("paused", paused);
  pauseBtn.title = paused ? "Resume" : "Pause";
  pauseBtn.innerHTML = paused ? PLAY_SVG : PAUSE_SVG;
  typingAnim.classList.toggle("paused", paused);
  typingAnimLabel.textContent = paused ? "Paused…" : "Typing…";
  typingProgress.classList.toggle("paused", paused);
}

function setTypingState(isTyping) {
  typeBtn.disabled       = isTyping;
  typeBtn.style.display  = isTyping ? "none" : "block";
  stopBtn.style.display  = isTyping ? "inline-flex" : "none";
  stopBtn.disabled       = !isTyping;
  pauseBtn.style.display = isTyping ? "inline-flex" : "none";
  pauseBtn.disabled      = !isTyping;
  backBtn.disabled       = isTyping;
  typingAnim.classList.toggle("active", isTyping);
  if (typeControlsEl) typeControlsEl.classList.toggle("typing", isTyping);
  if (!isTyping) {
    resetTypingProgress();
    setPauseState(false);
  }
}

// ─────────────────────────────────────────────
//  START TYPING
// ─────────────────────────────────────────────
typeBtn.addEventListener("click", () => {
  const text = getActiveTypingText();
  const rawWpm = parseInt(wpmEl.value) || 80;

  if (!text.trim())           { setStatus("No text to type.", "err"); return; }
  if (!parseInt(wpmEl.value)) { markError(wpmEl); wpmEl.focus(); return; }

  // Enforce WPM cap for free tier
  const limits = TIER_LIMITS[currentTier] || TIER_LIMITS.free;
  let wpm = rawWpm;
  if (limits.maxWpm !== Infinity && wpm > limits.maxWpm) {
    wpm = limits.maxWpm;
    wpmEl.value = String(wpm);
    flashElement(wpmEl, "input-cap-flash");
    flashElement(wpmCrown, "lock-flash");
  }

  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.url?.includes("docs.google.com")) {
      setStatus("❌ Open a Google Doc first.", "err");
      return;
    }

    setTypingState(true);
    setPauseState(false);
    setStatus("", "");
    typingAnimLabel.textContent = "Typing…";
    updateTypingProgress(0);

    chrome.scripting.executeScript(
      { target: { tabId: tab.id }, files: ["content.js"] },
      () => {
        if (chrome.runtime.lastError) {
          setStatus("❌ " + chrome.runtime.lastError.message, "err");
          setTypingState(false);
          return;
        }
        setTimeout(() => {
          chrome.tabs.sendMessage(tab.id, { action: "type", text, wpm }, (response) => {
            if (chrome.runtime.lastError) {
              setStatus("❌ " + chrome.runtime.lastError.message, "err");
            } else if (response?.stopped) {
              setStatus("", "");
            } else {
              setStatus("✓ Done!", "ok");
              showToast("Essay complete!", "ok");
              fireConfetti();
            }
            setTypingState(false);
          });
        }, 150);
      }
    );
  });
});

// ─────────────────────────────────────────────
//  PAUSE / RESUME
// ─────────────────────────────────────────────
pauseBtn.addEventListener("click", () => {
  if (pauseBtn.disabled) return;
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab) return;
    const action = typingPaused ? "resume" : "pause";
    chrome.tabs.sendMessage(tab.id, { action }, (resp) => {
      if (chrome.runtime.lastError) {
        setStatus("❌ " + chrome.runtime.lastError.message, "err");
        return;
      }
      if (resp?.paused) setPauseState(true);
      else if (resp?.resumed) setPauseState(false);
      else if (action === "pause") setPauseState(true);
    });
  });
});

// ─────────────────────────────────────────────
//  STOP TYPING
// ─────────────────────────────────────────────
stopBtn.addEventListener("click", () => {
  chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab) return;
    chrome.tabs.sendMessage(tab.id, { action: "stop" }, () => {
      setStatus("", "");
    });
  });
});